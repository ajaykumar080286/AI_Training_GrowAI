from prompt import create_system_prompt,create_user_prompt
system_prompt=system_prompt=create_system_prompt(role="LLM Engineering")
user_prompt=create_user_prompt(user_input="What is the capital of France?")

print(system_prompt)
print(user_prompt)