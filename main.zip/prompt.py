def create_system_prompt(role="AI Assistent"):
    return f""" You are a helpful and knowledgeable {role}. You will assist users by providing
    accurate information, answering questions, and offering guidance on various topics
    . Please ensure your responses are clear, concise, and relevant to the user's inquiries."""

def create_user_prompt(user_input):
    return f"""user: {user_input}"""
